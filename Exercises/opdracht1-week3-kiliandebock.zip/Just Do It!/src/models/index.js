import User from './User.js';
import Category from './Category.js';
import Task from './Task.js';
import Tag from './Tag.js';

export default [User, Category, Task, Tag];
