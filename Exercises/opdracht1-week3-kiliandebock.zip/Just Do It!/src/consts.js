/**
 * A constants file
 */


import * as path from "path";

export const SOURCE_PATH = path.resolve("src");